# Statistics 209: Introduction to Statistical Modeling

This repository is where you will save results from any in-class labs,
due most class meetings, and the data projects. We will explain in more
detail during class how these will be structured.

